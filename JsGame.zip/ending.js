var myTimer = setTimeout(function() {

  location.href='game_userMove.html'
  }, 112000);
  
//   clearTimeout(myTimer);112000
  